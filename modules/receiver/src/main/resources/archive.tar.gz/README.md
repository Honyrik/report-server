## Report Schema
## Установка бд
Правим liquibase.report.properties прописываем адрес нашей бд essence_report и пользователя

Запускаем 
```
update
```
Проверяем main.log

Пример успешного ответа
```
Starting Liquibase at Пт, 10 янв 2020 09:00:24 MSK (version 3.6.3 built at 2019-01-29 11:34:48)
Liquibase: Update has been successful.
```